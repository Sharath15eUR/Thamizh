#!/bin/bash

if [ "$#" -ne 3 ]; then
	echo "Invalid arguments, provide in <Source> <Destination> <extension>"
	exit 1
fi

SOURCE_DIR=$1
BACKUP_DIR=$2
FILE_EXTENSION=$3

FILES=("$SOURCE_DIR"/*"$FILE_EXTENSION")

echo "The files are ${FILES[@]}"

export BACKUP_COUNT=0

if [ ! -d "$BACKUP_DIR" ]; then
	mkdir -p "$BACKUP_DIR" || { echo "Error creating Directory"; exit 1; }
fi

if [ "${#FILES[@]}" -eq 0 ]; then
	echo "No files found with matching extension !"; exit 0
fi

echo "List of files ready for backup: "

for FILE in "${FILES[@]}"; do
	if [ -f "$FILE" ]; then
	    echo " $(basename "$FILE") - $(stat -c%s "$FILE") bytes"
	fi
done

#BACKUP

TOTAL_SIZE=0


for FILE in "${FILES[@]}"; do
	if [ -f "$FILE" ]; then
	   DEST_FILE="$BACKUP_DIR/$(basename "$FILE")"

		if [ -e "$DEST_FILE" ]; then
		   if [ "$FILE" -nt "$DEST_FILE" ]; then
			cp "$FILE" "$DEST_FILE"
		   fi
	        else
		   cp "$FILE" "$DEST_FILE"
		fi


	  TOTAL_SIZE=$((TOTAL_SIZE + $(stat -c%s "$FILE")))
	  BACKUP_COUNT=$((BACKUP_COUNT+1))
	fi
done


#REPORT_GENERATION

REPORT="$BACKUP_DIR/backup_report.log"

{
	echo "Total Files Processed: $BACKUP_COUNT"
	echo "Total size of files backed up: $TOTAL_SIZE"
	echo "Path to Backup directory: $BACKUP_DIR"
}>"$REPORT"

echo "Backup completed"


